document.addEventListener("DOMContentLoaded", function () {
  // DOM Elements
  const taskForm = document.getElementById("task-form");
  const taskInput = document.getElementById("task-input");
  const tasksContainer = document.getElementById("tasks-container");
  const themeBtn = document.getElementById("theme-btn");
  const filterBtns = document.querySelectorAll(".filter-btn");
  const clearCompletedBtn = document.getElementById("clear-completed");
  const taskCount = document.getElementById("task-count");
  const addTaskBtn = document.getElementById("add-task-btn");

  // State
  let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  let currentFilter = "all";

  // Initialize app
  renderTasks();
  updateTaskCount();

  // Event Listeners
  taskForm.addEventListener("submit", function (e) {
    e.preventDefault();
    addTask();
  });

  addTaskBtn.addEventListener("click", function (e) {
    if (taskForm.reportValidity()) {
      addTask();
    }
  });

  themeBtn.addEventListener("click", toggleTheme);
  clearCompletedBtn.addEventListener("click", clearCompletedTasks);

  filterBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      filterBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      currentFilter = btn.dataset.filter;
      renderTasks();
    });
  });

  // Functions
  function addTask() {
    const taskText = taskInput.value.trim();
    if (!taskText) return;

    const newTask = {
      id: Date.now(),
      text: taskText,
      completed: false,
      category: document.getElementById("category-select").value,
      dueDate: document.getElementById("due-date").value || null,
      createdAt: new Date().toISOString(),
    };

    tasks.unshift(newTask);
    saveTasks();
    renderTasks();
    updateTaskCount();

    taskInput.value = "";
    taskInput.focus();
    document.getElementById("due-date").value = "";
  }

  function renderTasks() {
    tasksContainer.innerHTML = "";

    const filteredTasks = tasks.filter((task) => {
      if (currentFilter === "all") return true;
      if (currentFilter === "active") return !task.completed;
      if (currentFilter === "completed") return task.completed;
      return true;
    });

    if (filteredTasks.length === 0) {
      tasksContainer.innerHTML =
        '<p class="empty-message">No tasks found. Add one above!</p>';
      return;
    }

    filteredTasks.forEach((task) => {
      const taskEl = document.createElement("li");
      taskEl.className = `task ${task.completed ? "completed" : ""} ${
        task.category
      }`;
      taskEl.dataset.id = task.id;

      taskEl.innerHTML = `
                <div class="task-content">
                    <input type="checkbox" ${task.completed ? "checked" : ""}>
                    <span class="task-text">${task.text}</span>
                    ${
                      task.dueDate
                        ? `<span class="due-date">📅 ${formatDate(
                            task.dueDate
                          )}</span>`
                        : ""
                    }
                </div>
                <button class="delete-btn">🗑️</button>
            `;

      const checkbox = taskEl.querySelector('input[type="checkbox"]');
      const deleteBtn = taskEl.querySelector(".delete-btn");

      checkbox.addEventListener("change", () => toggleTaskComplete(task.id));
      deleteBtn.addEventListener("click", () => deleteTask(task.id));

      tasksContainer.appendChild(taskEl);
    });
  }

  function toggleTaskComplete(taskId) {
    tasks = tasks.map((task) => {
      if (task.id === taskId) {
        return { ...task, completed: !task.completed };
      }
      return task;
    });
    saveTasks();
    updateTaskCount();
  }

  function deleteTask(taskId) {
    tasks = tasks.filter((task) => task.id !== taskId);
    saveTasks();
    renderTasks();
    updateTaskCount();
  }

  function clearCompletedTasks() {
    tasks = tasks.filter((task) => !task.completed);
    saveTasks();
    renderTasks();
    updateTaskCount();
  }

  function updateTaskCount() {
    const activeTasks = tasks.filter((task) => !task.completed).length;
    taskCount.textContent = activeTasks;
  }

  function saveTasks() {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }

  function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute("data-theme");
    const newTheme = currentTheme === "light" ? "dark" : "light";
    document.documentElement.setAttribute("data-theme", newTheme);
    themeBtn.textContent =
      newTheme === "light" ? "🌙 Dark Mode" : "☀️ Light Mode";
    localStorage.setItem("theme", newTheme);
  }

  function formatDate(dateString) {
    const options = { year: "numeric", month: "short", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  }

  // Initialize theme from localStorage
  const savedTheme = localStorage.getItem("theme") || "light";
  document.documentElement.setAttribute("data-theme", savedTheme);
  themeBtn.textContent =
    savedTheme === "light" ? "🌙 Dark Mode" : "☀️ Light Mode";
});
