document.addEventListener("DOMContentLoaded", () => {
  const taskInput = document.getElementById("newTask");
  const addTaskButton = document.getElementById("addTaskBtn");
  const taskList = document.getElementById("taskList");
  const clearCompletedButton = document.getElementById("clearCompletedBtn");

  let tasks = loadTasks();
  renderTasks();

  addTaskButton.addEventListener("click", addTask);
  clearCompletedButton.addEventListener("click", clearCompletedTasks);
  taskList.addEventListener("change", toggleComplete);
  taskList.addEventListener("click", deleteTask);

  function loadTasks() {
    const storedTasks = localStorage.getItem("tasks");
    return storedTasks ? JSON.parse(storedTasks) : [];
  }

  function saveTasks() {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }

  function renderTasks() {
    taskList.innerHTML = "";
    tasks.forEach((task, index) => {
      const listItem = document.createElement("li");
      listItem.innerHTML = `
                <input type="checkbox" data-index="${index}" ${
        task.completed ? "checked" : ""
      }>
                <span>${task.text}</span>
                <button data-index="${index}">✕</button>
            `;
      listItem.classList.toggle("completed", task.completed);
      taskList.appendChild(listItem);
    });
  }

  function addTask() {
    const newTaskText = taskInput.value.trim();
    if (newTaskText !== "") {
      tasks.push({ text: newTaskText, completed: false });
      saveTasks();
      renderTasks();
      taskInput.value = "";
    }
  }

  function toggleComplete(event) {
    if (event.target.type === "checkbox") {
      const index = event.target.dataset.index;
      tasks[index].completed = !tasks[index].completed;
      saveTasks();
      renderTasks();
    }
  }

  function deleteTask(event) {
    if (event.target.tagName === "BUTTON") {
      const index = event.target.dataset.index;
      tasks.splice(index, 1);
      saveTasks();
      renderTasks();
    }
  }

  function clearCompletedTasks() {
    tasks = tasks.filter((task) => !task.completed);
    saveTasks();
    renderTasks();
  }
});
